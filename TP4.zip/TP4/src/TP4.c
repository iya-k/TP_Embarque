/*
 * TP4.c
 *
 *  Created on: 27 nov. 2019
 *      Author: skaba
 */

#include <stdio.h>
#include <stdlib.h>
#include <asm-leon/irq.h>
#include <asm-leon/timer.h>
#include <stdint.h>

int main(void) {

	printf("TP4 s\n");
	return EXIT_SUCCESS;
}


